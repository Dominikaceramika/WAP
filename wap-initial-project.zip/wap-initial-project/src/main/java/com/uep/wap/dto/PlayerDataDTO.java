package com.uep.wap.dto;

import java.util.List;

public class PlayerDataDTO {
    List<PlayerDTO> people;

    public List<PlayerDTO> getPeople() {
        return people;
    }

    public void setPeople(List<PlayerDTO> people) {
        this.people = people;
    }
}

